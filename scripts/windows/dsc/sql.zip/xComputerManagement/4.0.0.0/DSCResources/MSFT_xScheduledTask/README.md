# Description

The resource is used to define basic run once or recurring scheduled tasks
on the local computer. It can also be used to delete or disable built-in
scheduled tasks.
