USE master
GO

SELECT COUNT(*) FROM sys.certificates