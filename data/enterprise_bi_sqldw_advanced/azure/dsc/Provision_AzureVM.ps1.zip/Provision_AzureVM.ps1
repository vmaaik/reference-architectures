Configuration Provision_AzureVM
{
    Param(
            [Parameter(Mandatory=$true)]
            [string]$IntegrationRuntimeGatewayKey
    )

    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName xPsDesiredStateConfiguration
    Import-DscResource -ModuleName xSystemSecurity -Name xIEEsc

    Node localhost {
        $packageFolder = "c:\SampleDataFiles"
        $downloadsFolder = Join-Path $packageFolder "\Downloads"
        $logFilesFolder = Join-Path $packageFolder "\Logs"

        # Microsoft Integration Runtime
        $mirLogPath = Join-Path $logFilesFolder "mir_log.txt"
        $mirDownloadUri = "https://download.microsoft.com/download/E/4/7/E4771905-1079-445B-8BF9-8A1A075D8A10/IntegrationRuntime_3.6.6681.4 (64-bit).msi"
        $mirMsiPath = Join-Path $downloadsFolder "\MicrosoftIntegrationRuntime.msi"
        $mirInstallPath = "C:\Program Files\Microsoft Integration Runtime"
        $mirRegistrationPath = Join-Path $mirInstallPath "3.0\PowerShellScript\RegisterIntegrationRuntime.ps1"
        $mirRegistrationArgumentList = @{gatewayKey=$IntegrationRuntimeGatewayKey}

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $false
            ConfigurationMode = "ApplyOnly"
        }

        # Create directory structure
        File PackageFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $packageFolder
        }

        File LogsFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $logFilesFolder
            DependsOn = "[File]PackageFolder"
        }

        File DownloadsFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $downloadsFolder
            DependsOn = "[File]PackageFolder"
        }

        # Disable Protected Mode so the sign-in experience to Azure Analysis Services is easier
        xIEEsc DisableIEEscAdmin
        {
            IsEnabled = $false
            UserRole = "Administrators"
        }

        # Download Microsoft Integration Runtime MSI
        xRemoteFile IntegrationRuntimeDownload
        {
            Uri = $mirDownloadUri
            DestinationPath = $mirMsiPath
            MatchSource = $false
            DependsOn = "[File]DownloadsFolder"
        }

        # Install Microsoft Integration Runtime
        Script IntegrationRuntimeInstall
        {
            GetScript = {
                return @{Result=""}
            }
            SetScript = {
                Write-Verbose "Installing Microsoft Integration Runtime (x64)"
                Start-Process -Wait -FilePath "c:\Windows\System32\msiexec.exe" `
                    -ArgumentList "/package `"$Using:mirMsiPath`"", "/qn", "/log `"$Using:mirLogPath`"", "/norestart"
                $arguments = $Using:mirRegistrationArgumentList
                & "$Using:mirRegistrationPath" @arguments
            }
            TestScript = {
                Write-Verbose "Finding Microsoft Integration Runtime (x64)"
                $exists = Test-Path $Using:mirInstallPath
                if ($exists) {
                    Write-Verbose "Microsoft Integration Runtime (x64) found"
                }

                return $exists
            }
            DependsOn = @("[xRemoteFile]IntegrationRuntimeDownload", "[File]LogsFolder")
        }
    }
}