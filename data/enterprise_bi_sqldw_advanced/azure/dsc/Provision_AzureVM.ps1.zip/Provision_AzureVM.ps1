Configuration Provision_AzureVM
{
    Param(
            [Parameter(Mandatory=$true)]
            [string]$IntegrationRuntimeGatewayKey
    )

    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName StorageDsc, xPsDesiredStateConfiguration, xPendingReboot
    Import-DscResource -ModuleName xSystemSecurity -Name xIEEsc

    Node localhost {
        $packageFolder = "c:\SampleDataFiles"
        $downloadsFolder = Join-Path $packageFolder "\Downloads"
        $logFilesFolder = Join-Path $packageFolder "\Logs"
        $projectFolder = Join-Path $packageFolder "\reference-architectures"

        # SQLCMD
        $sqlcmdLogPath = Join-Path $logFilesFolder "\sqlcmd_log.txt"
        $sqlcmdDownloadUri = "https://download.microsoft.com/download/C/8/8/C88C2E51-8D23-4301-9F4B-64C8E2F163C5/x64/MsSqlCmdLnUtils.msi"
        $sqlcmdInstallerPath = Join-Path $downloadsFolder "\MsSqlCmdLnUtils.msi"

        # SQL Server ODBC Driver
        $odbcLogPath = Join-Path $logFilesFolder "\sql_server_odbc.txt"
        $odbcDownloadUri = "https://download.microsoft.com/download/D/5/E/D5EEF288-A277-45C8-855B-8E2CB7E25B96/x64/msodbcsql.msi"
        $odbcInstallerPath = Join-Path $downloadsFolder "\msodbcsql.msi"

        # Git for Windows
        $gitLogPath = Join-Path $logFilesFolder "\git_log.txt"
        $gitDownloadUri = "https://github.com/git-for-windows/git/releases/download/v2.16.2.windows.1/Git-2.16.2-64-bit.exe"
        $gitInstallerPath = Join-Path $downloadsFolder "\GitInstall.exe"
        $gitInstallPath = "C:\Program Files\Git"
        $gitPath = Join-Path $gitInstallPath "\cmd\git.exe"

        # Microsoft Integration Runtime
        $mirLogPath = Join-Path $logFilesFolder "mir_log.txt"
        $mirDownloadUri = "https://download.microsoft.com/download/E/4/7/E4771905-1079-445B-8BF9-8A1A075D8A10/IntegrationRuntime_3.6.6681.4 (64-bit).msi"
        $mirMsiPath = Join-Path $downloadsFolder "\MicrosoftIntegrationRuntime.msi"
        $mirInstallPath = "C:\Program Files\Microsoft Integration Runtime"
        $mirRegistrationPath = Join-Path $mirInstallPath "3.0\PowerShellScript\RegisterIntegrationRuntime.ps1"
        $mirRegistrationArgumentList = @{gatewayKey=$IntegrationRuntimeGatewayKey}

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        # Create directory structure
        File PackageFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $packageFolder
        }

        File LogsFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $logFilesFolder
            DependsOn = "[File]PackageFolder"
        }

        File DownloadsFolder
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $false
            DestinationPath = $downloadsFolder
            DependsOn = "[File]PackageFolder"
        }

        # Disable Protected Mode so the sign-in experience to Azure Analysis Services is easier
        xIEEsc DisableIEEscAdmin
        {
            IsEnabled = $false
            UserRole = "Administrators"
        }

        # Download Git for Windows
        Script GitDownload
        {
            GetScript = {
                return @{Result=""}
            }
            SetScript = {
                Write-Verbose "Downloading $Using:gitDownloadUri to $Using:gitInstallerPath"
                [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
                Invoke-WebRequest -Uri $Using:gitDownloadUri -OutFile $Using:gitInstallerPath
            }
            TestScript = {
                Write-Verbose "Finding '$Using:gitInstallerPath'"
                $fileExists = Test-Path $Using:gitInstallerPath
                if ($fileExists) {
                    Write-Verbose "DestinationPath: '$Using:gitInstallerPath' is existing file on the machine"
                }

                return $fileExists
            }
            DependsOn = "[File]DownloadsFolder"
        }

        # Download Microsoft Integration Runtime MSI
        xRemoteFile IntegrationRuntimeDownload
        {
            Uri = $mirDownloadUri
            DestinationPath = $mirMsiPath
            MatchSource = $false
            DependsOn = "[File]DownloadsFolder"
        }

        # Download SQLCMD
        xRemoteFile SqlCmdDownload
        {
            Uri = $sqlcmdDownloadUri
            DestinationPath = $sqlcmdInstallerPath
            MatchSource = $false
            DependsOn = "[File]DownloadsFolder"
        }

        # SQL Server ODBC Driver
        xRemoteFile OdbcDownload
        {
            Uri = $odbcDownloadUri
            DestinationPath = $odbcInstallerPath
            MatchSource = $false
            DependsOn = "[File]DownloadsFolder"
        }

        # Install Git for Windows
        Script GitInstall
        {
            GetScript = {
                return @{Result=""}
            }
            SetScript = {
                Write-Verbose "Installing Git for Windows"
                Start-Process -Wait -FilePath "$Using:gitInstallerPath" `
                    -ArgumentList "/VERYSILENT", "/SUPPRESSMSGBOXES", "/LOG=`"$Using:gitLogPath`"", "/NOCANCEL", "/NORESTART"
                # The installer just exits so we can't wait on it.  We'll sleep for a minute and a half and send the broadcast.
                # This usually takes ~30 seconds to run
                Start-Sleep -Seconds 90
            }
            TestScript = {
                Write-Verbose "Finding Git for Windows"
                $gitExists = Test-Path $Using:gitInstallPath
                if ($gitExists) {
                    Write-Verbose "Git for Windows found"
                }

                return $gitExists
            }
            Credential = $SqlUserCredentials
            DependsOn = @("[Script]GitDownload", "[File]LogsFolder")
        }

        # Clone our repo
        Script CloneProject
        {
            GetScript = {
                return @{Result=""}
            }
            SetScript = {
                Write-Verbose "Cloning project..."
                Start-Process -Wait -FilePath $Using:gitPath -ArgumentList "clone", "https://github.com/mspnp/reference-architectures.git", `
                    "--branch", "master", "--depth", "1", "--single-branch", "--no-checkout" -WorkingDirectory $Using:packageFolder
                Start-Process -Wait -FilePath $Using:gitPath -ArgumentList "config", "core.sparseCheckout", "true" -WorkingDirectory $Using:projectFolder
                "data/*" | Out-File -Encoding ascii (Join-Path $Using:projectFolder "\.git\info\sparse-checkout")
                Start-Process -Wait -FilePath $Using:gitPath -ArgumentList "checkout", "master" -WorkingDirectory $Using:projectFolder
            }
            TestScript = {
                Write-Verbose "Finding project directory"
                $cloneExists = Test-Path $Using:projectFolder
                if ($cloneExists) {
                    Write-Verbose "Project directory found"
                }

                return $cloneExists
            }
            DependsOn = @("[Script]GitInstall", "[File]PackageFolder")
        }

        # Install Microsoft Integration Runtime
        Script IntegrationRuntimeInstall
        {
            GetScript = {
                return @{Result=""}
            }
            SetScript = {
                Write-Verbose "Installing Microsoft Integration Runtime (x64)"
                Start-Process -Wait -FilePath "c:\Windows\System32\msiexec.exe" `
                    -ArgumentList "/package `"$Using:mirMsiPath`"", "/qn", "/log `"$Using:mirLogPath`"", "/norestart"
                $arguments = $Using:mirRegistrationArgumentList
                & "$Using:mirRegistrationPath" @arguments
            }
            TestScript = {
                Write-Verbose "Finding Microsoft Integration Runtime (x64)"
                $exists = Test-Path $Using:mirInstallPath
                if ($exists) {
                    Write-Verbose "Microsoft Integration Runtime (x64) found"
                }

                return $exists
            }
            DependsOn = @("[Script]CloneProject", "[xRemoteFile]IntegrationRuntimeDownload", "[File]LogsFolder")
        }

        xPendingReboot RebootAfterInstalls
        {
            Name = "RebootAfterInstalls"
            DependsOn = "[Script]IntegrationRuntimeInstall"
        }
    }
}